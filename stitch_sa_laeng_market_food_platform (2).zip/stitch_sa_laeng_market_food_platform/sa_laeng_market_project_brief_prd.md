# Project Brief: Sa-laeng Market

## 1. Project Overview
**Sa-laeng Market** is a localized multi-vendor street food marketplace designed for a specific village community. The platform aims to facilitate local trade, provide income opportunities for residents, and offer a convenient food ordering and delivery service within the neighborhood.

## 2. Target Audience
*   **Customers:** Residents within the village looking for local street food.
*   **Merchants:** Local food stall owners and home cooks within the village.
*   **Admin:** A single system owner who manages the platform and oversees deliveries.

## 3. Core Features & Business Logic

### 3.1 Delivery & Pricing
*   **Base Delivery Fee:** ฿10 for distances up to 1 kilometer.
*   **Extended Delivery Fee:** Additional ฿10 per kilometer for distances exceeding 1 km.
*   **Merchant Fees:**
    *   **Transaction Fee:** 3% commission per order.
    *   **Partner Fee:** ฿50 monthly subscription for merchants.

### 3.2 User Roles & Permissions
*   **Customers:**
    *   Browse local merchants and menus.
    *   Place orders (restricted to one shop per order for delivery efficiency).
    *   Track order status in real-time.
    *   Order cancellation is allowed only within **1 minute** of placing the order.
*   **Merchants:**
    *   Manage digital storefront and menu items (upload photos, set prices, manage stock).
    *   Toggle shop status (Open/Closed).
    *   Accept or Reject incoming orders.
*   **Admin (Owner):**
    *   Full platform control and visibility.
    *   Approve/Suspend merchants.
    *   Oversee all active orders and platform financials (commission and subscription tracking).
    *   Act as the primary support/chat operator.

### 3.3 Key Interaction Flows
*   **Ordering:** Customers select food -> calculate delivery based on distance -> pay -> track.
*   **Fulfillment:** Merchant receives order notification -> accepts -> prepares -> Admin/Courier delivers.
*   **Support:** Integrated chat between customers, riders (Admin), and merchants for smooth coordination.

## 4. Visual Identity & Design Direction
*   **Brand Name:** Sa-laeng Market
*   **Theme:** Fresh Market Narrative (Friendly, local, and professional).
*   **Primary Color:** #22c55e (Vibrant Green).
*   **Language:** Full Thai support for all interfaces to ensure accessibility for the local community.
*   **Device Support:** Desktop-first (with mobile-responsive considerations for on-the-go tracking).

## 5. Screen Inventory (Established)
1.  **Homepage:** Search, categories, and featured local stalls.
2.  **Login & Registration:** Dual-entry for customers and merchants.
3.  **Cart & Checkout:** Fee breakdown and address selection.
4.  **Order Tracking:** Real-time status updates and delivery map.
5.  **Merchant Dashboard:** Menu management, financial tracking, and order controls.
6.  **Admin Dashboard:** Platform income overview, merchant approval, and global order control.
7.  **Chat & Support:** Centralized communication hub.

## 6. Technical Requirements
*   Real-time notifications for new orders.
*   Distance-based calculation engine for delivery fees.
*   Financial reporting for merchant payouts and admin revenue.

---
name: Fresh Market Narrative
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4a3d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7b6c'
  outline-variant: '#bccbb9'
  surface-tint: '#006e2f'
  primary: '#006e2f'
  on-primary: '#ffffff'
  primary-container: '#22c55e'
  on-primary-container: '#004b1e'
  inverse-primary: '#4ae176'
  secondary: '#9d4300'
  on-secondary: '#ffffff'
  secondary-container: '#fd761a'
  on-secondary-container: '#5c2400'
  tertiary: '#005ac2'
  on-tertiary: '#ffffff'
  tertiary-container: '#82abff'
  on-tertiary-container: '#003d88'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#6bff8f'
  primary-fixed-dim: '#4ae176'
  on-primary-fixed: '#002109'
  on-primary-fixed-variant: '#005321'
  secondary-fixed: '#ffdbca'
  secondary-fixed-dim: '#ffb690'
  on-secondary-fixed: '#341100'
  on-secondary-fixed-variant: '#783200'
  tertiary-fixed: '#d8e2ff'
  tertiary-fixed-dim: '#adc6ff'
  on-tertiary-fixed: '#001a42'
  on-tertiary-fixed-variant: '#004395'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1280px
  gutter: 20px
---

## Brand & Style
The design system is engineered for a high-efficiency multi-vendor food marketplace, balancing the energy of street food culture with the reliability of a professional logistics platform. The target audience includes busy urban consumers and micro-entrepreneurs who require a frictionless, trustworthy interface.

The design style is **Corporate / Modern** with a **Tactile** edge. It utilizes a clean, card-based architecture that prioritizes high-quality food photography. The interface is characterized by high legibility, intentional whitespace, and soft depth markers that make the UI feel approachable yet structurally robust. The goal is to evoke a sense of freshness, speed, and reliability.

## Colors
The palette is driven by a high-visibility "Fresh & Zesty" duo. 
- **Primary Green (#22C55E):** Used for growth, success states, and primary actions related to ordering and confirmation.
- **Secondary Orange (#F97316):** Used for high-energy accents, promotions, and brand markers that stimulate appetite.
- **Neutrals:** A range of Slate grays provides a sophisticated backdrop, ensuring that colorful food imagery remains the focal point.
- **System States:** Error (#EF4444), Warning (#F59E0B), and Info (#3B82F6) follow standard accessibility patterns.

## Typography
The typography system uses **Inter** to ensure maximum legibility and cross-platform compatibility, especially for technical data like prices and distances. 

- **Headlines:** Use Bold and Semi-Bold weights with tight letter spacing to create a modern, editorial feel.
- **Body Text:** Standardizes on 16px for comfortable long-form reading in menu descriptions.
- **Numerical Data:** Price points and ratings should use Semi-Bold weights to ensure they stand out within dense restaurant cards.
- **Thai Language Support:** While Inter is specified, the system is designed to fall back to **Prompt** or **Sarabun** for Thai script to maintain a professional, modern aesthetic.

## Layout & Spacing
This design system utilizes a **12-column fluid grid** for desktop and a **4-column grid** for mobile devices. 

- **Modular Scale:** A 4px baseline grid governs all spatial relationships. 16px (md) is the standard padding for containers and cards.
- **Responsiveness:** 
  - **Mobile (<640px):** Full-width cards with 16px horizontal margins.
  - **Tablet (640px - 1024px):** 2-column card layouts.
  - **Desktop (>1024px):** Fixed sidebar for dashboards (280px) with fluid content area.
- **Safe Areas:** Navigation bars and action buttons must respect mobile safe-area insets for modern edge-to-edge displays.

## Elevation & Depth
Depth is communicated through **Ambient Shadows** and **Tonal Layers**. 

- **Level 0 (Base):** Neutral-50 (#F8FAFC) background.
- **Level 1 (Cards):** White background with a soft, diffused shadow: `0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)`. Used for restaurant listings and menu items.
- **Level 2 (Dropdowns/Modals):** Increased elevation with a larger blur radius: `0 20px 25px -5px rgb(0 0 0 / 0.1)`.
- **Interactive States:** On hover, cards should lift slightly (translate -2px) and the shadow intensity should increase to provide tactile feedback.

## Shapes
The shape language is extremely soft and welcoming, utilizing **2xl (1.5rem / 24px)** as the primary radius for large cards and containers.

- **Small elements (Buttons, Inputs):** 0.5rem (8px).
- **Medium elements (Modals, Feature blocks):** 1rem (16px).
- **Large elements (Restaurant Cards, Hero Sections):** 1.5rem (24px).
- **Interactive UI:** Checkboxes use a 4px radius, while radio buttons remain fully circular.

## Components
- **Restaurant Cards:** Feature a top-aligned image with a 16:9 aspect ratio, internal padding for text metadata, and floating badges for "Distance" and "Rating."
- **Search Bars:** High-visibility input with a leading location icon. Includes a "Detect Location" text button on the trailing edge.
- **Category Chips:** Pill-shaped (rounded-full) containers with a subtle 1px border. Active state uses the Primary Green background with white text.
- **Buttons:**
  - *Primary:* Solid Green, white text, bold weight.
  - *Secondary:* Ghost style with Primary Green border and text.
  - *Promotion:* Solid Orange to draw immediate attention to discounts.
- **Dashboard Sidebar:** Uses a flat design with subtle background highlights for active states. Icons should be stroke-based (2px width) for a modern, airy feel.
- **Menu Management Forms:** Use stacked labels, clear helper text, and large touch targets for price inputs and availability toggles.
- **Status Badges:** Rounded-full with low-opacity backgrounds (e.g., 10% Green for "Open", 10% Red for "Closed").